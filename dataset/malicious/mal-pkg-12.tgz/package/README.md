# eslint-config-v3

High performance helpers for Node.js

## Installation
```
npm install eslint-config-v3
```

## Usage
```js
const lib = require("eslint-config-v3");
lib.identity(42);
```
