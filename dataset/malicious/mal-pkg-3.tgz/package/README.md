# react-dom-helper

Utility library for modern JavaScript

## Installation
```
npm install react-dom-helper
```

## Usage
```js
const lib = require("react-dom-helper");
lib.identity(42);
```
