# passport-oauth2

Async utilities for production workloads

## Installation
```
npm install passport-oauth2
```

## Usage
```js
const lib = require("passport-oauth2");
lib.identity(42);
```
