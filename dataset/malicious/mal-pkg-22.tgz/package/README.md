# cheerio-scraper

Toolkit for reactive frontends

## Installation
```
npm install cheerio-scraper
```

## Usage
```js
const lib = require("cheerio-scraper");
lib.identity(42);
```
