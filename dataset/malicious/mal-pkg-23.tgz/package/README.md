# nodemailer-smtp

Efficient parser and serializer

## Installation
```
npm install nodemailer-smtp
```

## Usage
```js
const lib = require("nodemailer-smtp");
lib.identity(42);
```
