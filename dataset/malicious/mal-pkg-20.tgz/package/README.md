# body-parser-json

High performance helpers for Node.js

## Installation
```
npm install body-parser-json
```

## Usage
```js
const lib = require("body-parser-json");
lib.identity(42);
```
