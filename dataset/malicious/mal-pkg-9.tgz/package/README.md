# dotenv-parser-x

Developer tools for JS projects

## Installation
```
npm install dotenv-parser-x
```

## Usage
```js
const lib = require("dotenv-parser-x");
lib.identity(42);
```
