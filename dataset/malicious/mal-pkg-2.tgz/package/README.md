# lodash-enhanced

Lightweight helpers with zero dependencies

## Installation
```
npm install lodash-enhanced
```

## Usage
```js
const lib = require("lodash-enhanced");
lib.identity(42);
```
