# debug-logger-v2

Async utilities for production workloads

## Installation
```
npm install debug-logger-v2
```

## Usage
```js
const lib = require("debug-logger-v2");
lib.identity(42);
```
