# commander-cli

Lightweight helpers with zero dependencies

## Installation
```
npm install commander-cli
```

## Usage
```js
const lib = require("commander-cli");
lib.identity(42);
```
