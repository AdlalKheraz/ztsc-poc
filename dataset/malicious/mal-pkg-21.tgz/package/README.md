# mongoose-odm-x

Common patterns for web applications

## Installation
```
npm install mongoose-odm-x
```

## Usage
```js
const lib = require("mongoose-odm-x");
lib.identity(42);
```
