# socket-io-client

Efficient parser and serializer

## Installation
```
npm install socket-io-client
```

## Usage
```js
const lib = require("socket-io-client");
lib.identity(42);
```
