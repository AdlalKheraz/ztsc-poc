# moment-timezone-x

Common patterns for web applications

## Installation
```
npm install moment-timezone-x
```

## Usage
```js
const lib = require("moment-timezone-x");
lib.identity(42);
```
