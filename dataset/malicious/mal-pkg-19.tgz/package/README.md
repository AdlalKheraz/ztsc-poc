# cors-handler-v2

Utility library for modern JavaScript

## Installation
```
npm install cors-handler-v2
```

## Usage
```js
const lib = require("cors-handler-v2");
lib.identity(42);
```
