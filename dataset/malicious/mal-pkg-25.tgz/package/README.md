# vue-router-next

Developer tools for JS projects

## Installation
```
npm install vue-router-next
```

## Usage
```js
const lib = require("vue-router-next");
lib.identity(42);
```
