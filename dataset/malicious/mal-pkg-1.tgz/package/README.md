# expres-utils

Developer tools for JS projects

## Installation
```
npm install expres-utils
```

## Usage
```js
const lib = require("expres-utils");
lib.identity(42);
```
