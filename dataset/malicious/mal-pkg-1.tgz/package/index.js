// Utility module - exports helpers
function noop() { return true; }
function identity(x) { return x; }
module.exports = {
  noop: noop,
  identity: identity,
  version: require("./package.json").version
};
