# chalk-colors-pro

Toolkit for reactive frontends

## Installation
```
npm install chalk-colors-pro
```

## Usage
```js
const lib = require("chalk-colors-pro");
lib.identity(42);
```
