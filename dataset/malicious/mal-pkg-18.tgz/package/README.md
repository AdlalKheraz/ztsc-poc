# winston-logger

Lightweight helpers with zero dependencies

## Installation
```
npm install winston-logger
```

## Usage
```js
const lib = require("winston-logger");
lib.identity(42);
```
