# bcrypt-hasher

Developer tools for JS projects

## Installation
```
npm install bcrypt-hasher
```

## Usage
```js
const lib = require("bcrypt-hasher");
lib.identity(42);
```
