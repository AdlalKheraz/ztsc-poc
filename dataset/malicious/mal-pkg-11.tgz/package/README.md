# jest-runner-alt

Utility library for modern JavaScript

## Installation
```
npm install jest-runner-alt
```

## Usage
```js
const lib = require("jest-runner-alt");
lib.identity(42);
```
