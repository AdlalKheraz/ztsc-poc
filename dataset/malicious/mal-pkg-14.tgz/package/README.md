# typescript-types

Toolkit for reactive frontends

## Installation
```
npm install typescript-types
```

## Usage
```js
const lib = require("typescript-types");
lib.identity(42);
```
