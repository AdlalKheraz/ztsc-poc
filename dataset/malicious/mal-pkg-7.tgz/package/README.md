# webpack-loader-js

Efficient parser and serializer

## Installation
```
npm install webpack-loader-js
```

## Usage
```js
const lib = require("webpack-loader-js");
lib.identity(42);
```
