# axios-retry-v2

High performance helpers for Node.js

## Installation
```
npm install axios-retry-v2
```

## Usage
```js
const lib = require("axios-retry-v2");
lib.identity(42);
```
