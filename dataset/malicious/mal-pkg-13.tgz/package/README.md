# prettier-format

Common patterns for web applications

## Installation
```
npm install prettier-format
```

## Usage
```js
const lib = require("prettier-format");
lib.identity(42);
```
