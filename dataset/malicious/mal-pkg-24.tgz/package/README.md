# rollup-plugin-v2

Async utilities for production workloads

## Installation
```
npm install rollup-plugin-v2
```

## Usage
```js
const lib = require("rollup-plugin-v2");
lib.identity(42);
```
